package cinemabook;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Cinemabook {
    String name = "";
    String getName = "";
    String order = "";    
    double amt;
    int num1 = 0;            
    int age = num1;
    int num2 = 0;
    int numt = 0;
    double price = 10.0;
    private BufferedReader movieList; // read the movie list file, in this case file on desktop
    private BufferedReader Sample;    // read any order purchased by user
    
    public Cinemabook() {

        Welcome();         // welcomes de user
        readMovieList();  // read the movie list and save it in memory
        getName();       // get the user's name  
        menu();         // is the main opition to access the movie list and to order any movie
        

    }    
      
    public void Welcome(){ // welcomes the user
         
        System.out.println("Welcome to Cine Brazil");
    }
    
    public void getName(){        // get the user's name and print it out 
        System.out.println("Please type your Name");	 
	 BufferedReader br = new BufferedReader (new InputStreamReader(System.in)); // read the user's name
	                 
             try{ // read the name
		 name = br.readLine();
		 		
	     }catch (IOException e){} // catch any error
	     System.out.println("Welcome to Cine Brazil: " + name);
    }     
    public void menu(){ // is the method that shows the movie list, order, previous order and quit
               
        System.out.println("Menu");        
        System.out.println(
            "  1) Movie List\n" +
            "  2) New Order\n" +
            "  3) Previous Order \n" +
            "  4) Quit\n ");
        
        int number = 0;
        
        try {
            
            System.out.println("Please select an option: \n");            
            BufferedReader f = new BufferedReader (new InputStreamReader(System.in));   // read the menu                                
            number = Integer.parseInt (f.readLine());
            
            switch (number) {
                case 1:
                    printMovieList();
                    break;
                case 2:
                    order();
                    break;
                case 3:
                    previousOrder();
                    break;
                case 4:
                    quit(); 
                    break;
                default:
                    System.out.println("Invalid menu selection.");
                    break;
            }                   
            
        }catch(IOException | NumberFormatException e){ // detect any error if user type a wrong number
            System.out.println("System error!!!");
        }
                 
    }
    
    public void printMovieList(){  // method that shows the movie list
        String line = "";
	String lineSplit = ";";

        try {            // 
 	System.out.println("Movie list:\n");
                                
            while ((line = this.movieList.readLine()) != null) {
                // use comma as separator
                String[] movies = line.split(lineSplit);
		System.out.println(movies[0] + "\t" 
                            + movies [1] + "\t" );
		}
            
            this.readMovieList();
            
        }       
        catch(Exception e){
            System.out.println("Error while reading movie list \n " + e.getMessage());
        }        
    }
    
    public void movieList(){ // method 
        System.out.println();
        
        try { 
            BufferedReader m = new BufferedReader(new FileReader("C:\\Users\\Icler\\Desktop\\movielist.txt")); // read the movie list
            String line = m.readLine();
            
            while(line !=  null){ 
                System.out.println(line);
                line = m.readLine();               
            }          
        }       
        catch(Exception e){
            System.out.println("Error while reading movie list \n " + e.getMessage());  
        }              
    }
    
    public BufferedReader readMovieList(){ //read the movie list from PC
       try {
            BufferedReader m = new BufferedReader(new FileReader("C:\\Users\\Icler\\Desktop\\movielist.txt"));
            movieList = new  BufferedReader(new FileReader("C:\\Users\\Icler\\Desktop\\movielist.txt"));
            
        } catch(Exception e){
            System.out.println("Error while reading movie list \n " + e.getMessage());
            
        }
        
        return movieList;
    }            
    
    public void order(){ // costruct the movie opition to the user
        System.out.println("Order");        
        BufferedReader o = new BufferedReader (new InputStreamReader(System.in));
        
        boolean correct = true;
        try {
            BufferedReader m = new BufferedReader(new FileReader("C:\\Users\\Icler\\Desktop\\movielist.txt")); // brings the movie list           
            String line = m.readLine();
            while(line !=  null){ 
                System.out.println(line);
                line = m.readLine();
               
            }
            
        }
        
            catch(Exception e){} // any error will be detected
        
        do{ 
            try{ // show the movie options on the screm
                 System.out.println("Please choose Your movie");
                 
                 int number = Integer.parseInt(o.readLine());
                 
                 if (number == 1){
                     
                     System.out.println("Dirty Dancing");
                     
                 }else if (number == 2){
                     
                     System.out.println("Gladiator");
                     
                 }else if (number == 3){
                     
                     System.out.println("Grease");
                     
                 }else if (number == 4){
                     
                     System.out.println("Father and Ted in Brazil");
                                                       
                 }else if (number == 5 ){
                     
                     System.out.println("Mrs brown in Rio de Janeiro");
                 }
                 
            } catch (NumberFormatException e ){
                
                System.out.println(" you entered a string");
                    correct = false;
            } catch (IOException e){
                
                System.out.println("I/O error ");
                correct = false;
                
            }
            
        }while(correct != true);
        
        System.out.println("How many tickets would you like?");      
                     
        try {
            numt = Integer. parseInt (o.readLine());
        }catch (IOException | NumberFormatException e) {
            System.out.println("Option error: ");
        }
        
        getData1();
        
        }        
          
       public void getData1(){ // 
            BufferedReader d = new BufferedReader(new InputStreamReader(System.in));
            try {
                System.out.println("Enter age");
                
                age = Integer.parseInt(d.readLine());
                
            }catch(IOException | NumberFormatException e){}
            
            printData();
       }
                            
        public void printData(){ // this method "if statement" is to apply discount if applyed
             double oap = 10.0;        
             
            if(age > 0 && age <= 12) {           
                amt = ((price *numt) / 100) * 60;
                // take 40% discount
                System.out.println(amt);
            }else if (age > 12 && age <=65 ){
                amt = (price * numt);
                System.out.println(amt);            
            }else if (age > 65){ 
                amt = ((price *numt)/ 100) * 80;
                System.out.println(amt);
                // take 20% discount 
                    
                           }
          writeToFile();
        }
        
    public void writeToFile(){ // method to write on file all previous the details such as name, age, movies and discounts
        
try {

PrintWriter writer = new PrintWriter("C:\\Users\\Icler\\Desktop\\Sample.txt", "UTF-8");// all the opition typed is printed on this file

writer.println("Your name is " + name);
writer.println("You chose " + numt + " ticket (s)");
writer.println("Your age is " + age);
writer.println("The total to be paid is â‚¬" + amt);

writer.close();

}catch(Exception e) {}

    

previousOrder();

} 
    public void previousOrder(){        
        System.out.println("PreviousOrder");
    BufferedReader po = new BufferedReader (new InputStreamReader (System.in));
        boolean correct = true;
        try {
	    BufferedReader por = new BufferedReader(new FileReader("C:\\Users\\Icler\\Desktop\\Sample.txt"));
			
	    String line = por.readLine();
	    while(line != null) {
			   
                System.out.println(line);
			   
                line = por.readLine();
			}
	}catch(Exception e){
            System.out.println(" " + e.getMessage());
            
        }   
    }
    public void quit(){ // quit the program or finish the user's purchase. Built in sensitive case
        
        System.out.println("Do you want to quit (Y/N)");
        String input = "";
        BufferedReader q = new BufferedReader(new InputStreamReader(System.in));
       
        try {
            input = q.readLine();            
             switch (input) {
                case "Y":
                case "y":
                    System.exit(0);
                    break;
                case "N":
                case "n":
                    menu();
                    break;
                default:
                    System.out.println("Invalid selection, please type Y or N");
                    break;
            }
            
        }
        catch (Exception e){
            
        }
 }        
       
    public static void main(String[] args) {  // this is the main method. It runs the program
        
        Cinemabook Cinema = new Cinemabook();    
            
        while (true)
            Cinema.menu();
    }    
}    


 



